#!/usr/bin/python
import matplotlib               
import numpy                    
from pylab import *
from matplotlib import pyplot as pl
from matplotlib import axis as ax
from matplotlib.ticker import MultipleLocator#, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
#from matplotlib.backends.backend_pdf import PdfPages
#pp = PdfPages('plots/130814_Hopkins_contour_xiMax_of_r_A.pdf')

c = loadtxt('output/130807_3D_A_dep.txt', unpack=True, usecols = [0])
C = (numpy.pi/2)*c
r = loadtxt('output/130807_3D_A_rho.txt', unpack=True, usecols = [0])
h = loadtxt('output/130807_3D_height.txt')#, unpack=True, usecols = [0,1])

X,Y=meshgrid(C,r)
h = numpy.nan_to_num(h)
fig = figure()
ax = fig.gca(projection = '3d')
#figure()
#contourf(X,Y,h, 1000, cmap = hot())
surf = ax.plot_surface(X,Y,h, rstride = 1, cstride = 1,alpha = 0.5, cmap = cm.jet, linewidth = 0.01, antialiased = True, shade = False)# True)#, cmap = hot()
cset = ax.contour(X,Y,h, zdir = 'z', offset = 0, cmap = cm.jet)
#cset = ax.contour(X,Y,h, zdir = 'x', offset = 20, cmap = cm.jet)
cset = ax.contour(X,Y,h, zdir = 'y', offset = 0, cmap = cm.binary)# puts plot of max xi vs discrete r values at r=0 plane
#CS = contour(X,Y,h, colors = 'k')
#man_loc = [(1,1),(2,2),(3,3),(4,4)]
#clabel(CS, inline =1,fmt = '%1.1f', fontsize = 18,color = 'k', manual = man_loc)
#ax.grid(on = True)
ax.view_init(elev = 34, azim = -135)
#xlabel(r'$\frac{2}{\pi}C$', size = 21)
#ylabel(r'$r$', size = 24)

ax.set_xlabel(r'$C\,\,\frac{\xi}{\omega_{0}}$', size = 22)
ax.set_ylabel(r'$r$', size = 22)
#ax.set_zlabel(r'$\xi/\omega_{0}$', size = 22)
#ax.axhline(y = 1, color = 'k', linewidth = 2)
savefig('plots/130904_Hopkins_contour_deltaA_r_xiw0.png', dpi = 300)
#cbar.ax.set_ylabel(r'$\frac{\xi}{\omega_{0}}$', size = 24)
#cbar.add_lines(CS)
show()
close()


