#!/usr/bin/python
import matplotlib               
import numpy                    
from pylab import *
from matplotlib import pyplot as pl
from matplotlib import axis as ax
from matplotlib.ticker import MultipleLocator#, FormatStrFormatter
#from scipy import integrate

# wai yim chings ab initio data for a-sio2 (no peak)
x_synth_eV, y_synth = numpy.loadtxt('a-sio2-eps2.txt', unpack=True, usecols = [0,1])
# Syntisized data (peak added), re and im eps, and osc str sum rule, as received from DD 6/18/13 
#x_Y24204K, y_Y24204K = numpy.loadtxt('Y24204K.txt', unpack=True, usecols = [0,1])# K => eps1
x_expt_eV, y_expt = numpy.loadtxt('Y24204L.txt', unpack=True, usecols = [0,1])# L => eps2

## CONVERT X DATA FROM eV TO FREQUENCY (w)
#-----------------------------------------------------------------
convert_w = 1.6022*10**(-19) # change omegas from eV (~energy gained by an e by moving thru electric pot diff of 1 Volt, (1 V (V = 1 J/Coulomb)* elctron charge = -1.602e-19 C)); 1 eV = (convert_w) joules
# make a copy of the theoretical data (copying is a good idea; setting things
# equal to each other is extremely dangerous
x_synth = convert_w * x_synth_eV 
x_expt = convert_w * x_expt_eV
 
## calc difference eps2_ab, eps2_synth for each omega
#-----------------------------------------------------------
pl.figure()
diff = y_expt - y_synth
pl.plot(x_synth, diff)

# plot line for y = 0
listofzeros = numpy.zeros(len(x_synth))
pl.plot(x_synth,listofzeros)
pl.show()

## DEFINE FUNCTIONS FOR CALCULATING e(iz)
#------------------------------------------------------------- 
kb = 1.3806*10**(-23) # J/K
T = 300 # K
hbar = 1.0546*10**(-34) # J/s

# Matsubara frequencies
ns = arange(0,100)
zs = ns*kb*T/hbar

#def eiz_arg(omega,eps2,ham):
#(omega*eps2)/(omega**2 + ham**2)

z =10.
eiz_arg = (x_syn*y_syn/(x_syn**2 +z**2) for x_syn,y_syn in zip(x_synth,y_synth)
#eiz_args = [eiz_arg(x_syn,y_syn,z) for x_syn, y_syn in zip(x_synth, y_synth)]#z in zs]
#for i,integrand in enumerate(eiz_arg):
eiz = numpy.trapz(eiz_arg,x_synth) #for eiz_ar,x_syn in zip()#integrate.simps(eiz_args,x_synth)
pl.plot(x_synth, eiz)
#1. + (2./pi) * 
## PLOTS
#-------------------------------------------------------------
pl.figure() # Plot of eps2 for an initio (no peak) and synth (exciton peak added) 
pl.plot(x_synth,y_synth, color = 'k',label=r'ab initio eps2', linestyle='-')
#pl.plot(x_Y24204K, y_Y24204K, color = 'b',label=r'eps1, file Y24204K', linestyle='--')
pl.plot(x_expt, y_expt, color = 'r',label=r'eps2, file Y24204L', linestyle='-')
pl.legend()
pl.title(r'eps- Ab Initio and Syntisized')
pl.xlabel(r'eV')
pl.ylabel(r'eps')
#ax.get_minor_ticks(10)
pl.show()

pl.figure()
#pl.plot(x_Y24204S, y_Y24204S, color = 'g',label='fSum Rule, file Y24204S', linestyle='-')
pl.legend()
#pl.title('fSum Rule for Experimental Data')
pl.title(r'$\delt$')
#lyplot.xlabel(r'eV')
#lyplot.ylabel(r'$/epsilon(/omega)$')
pl.show()



