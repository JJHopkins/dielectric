#!/usr/bin/python
import matplotlib               
import numpy                    
from pylab import *
from matplotlib import pyplot as pl
from matplotlib import axis as ax
from matplotlib.ticker import MultipleLocator#, FormatStrFormatter
#from scipy import integrate
from matplotlib.backends.backend_pdf import PdfPages
pp = PdfPages('130709_Hopkins_df_DF_plots_only.pdf')

# wai yim chings ab initio data for a-sio2 (no peak)
x_nopeak_eV, y_nopeak = numpy.loadtxt('a-sio2-eps2.txt', unpack=True, usecols = [0,1])
# Syntisized data (peak added), re and im eps, and osc str sum rule, as received from DD 6/18/13 
x_Re_expt_eV, y_Re_expt = numpy.loadtxt('Y24204K.txt', unpack=True, usecols = [0,1])# K => eps1
x_peak_eV, y_peak = numpy.loadtxt('Y24204L.txt', unpack=True, usecols = [0,1])# L => eps2

## CONVERT X DATA FROM eV TO FREQUENCY rad/s(w)
#-----------------------------------------------------------------
# change omegas from eV = hbar * w 
# eV~energy gained by an e by moving thru electric pot diff of 1 Volt,  
# (V = 1 J/Coulomb)* elctron charge = -1.602e-19 C));
hbar = 6.5821*1e-16 # eV/sec

x_nopeak = x_nopeak_eV / hbar 
#y_nopeak = y_nopeak_eV / hbar 

x_peak =  x_peak_eV / hbar
#y_peak =  y_peak_eV / hbar

x_Re_expt = x_Re_expt_eV / hbar 
#y_Re_expt = y_Re_expt_eV /hbar

## DEFINE FUNCTIONS FOR CALCULATING e(iz)
#------------------------------------------------------------- 
# Matsubara frequencies: z_n at room temp is (2pikbT/hbar)*n (ie coeff*n)
coeff = (2.41*1e14) # in rad/s

n = arange(0,500)
z = n * coeff

eiz_nopeak = numpy.empty(len(z))
eiz_peak = numpy.empty(len(z))

sum_Li2 = numpy.empty(len(z))
dF = numpy.empty(len(z))
sum_dF =  0.0
sum_F =  0.0
sum_F_p =  0.0
diff_sum_F =  0.0

sum_Li3 = numpy.empty(len(z))
sum_Li3_p = numpy.empty(len(z))
F_3 = numpy.empty(len(z))
F_3_p = numpy.empty(len(z))

for j in range(len(z)):
    eiz_nopeak_arg=numpy.empty(len(x_nopeak))
    eiz_peak_arg=numpy.empty(len(x_peak))

    for i in range(len(x_nopeak)):
        eiz_nopeak_arg[i]=x_nopeak[i]*y_nopeak[i] / (x_nopeak[i]**2 + z[j]**2)
    eiz_nopeak[j] = 1 + (2./numpy.pi) * numpy.trapz(eiz_nopeak_arg,x_nopeak)

    for k in range(len(x_peak)):
        eiz_peak_arg[k]=x_peak[k]*y_peak[k] / (x_peak[k]**2 + z[j]**2)
	eiz_peak[j] = 1 + (2./numpy.pi) * numpy.trapz(eiz_peak_arg,x_peak)    

    sum_Li2[j] = 0.0
    for m in arange(101) + 1:
        sum_Li2[j] += ((((eiz_nopeak[j] -1)/(eiz_nopeak[j] +1))**2)**m)/(m**2)
    #sum_dF += -sum_Li2[j]*(1-((eiz_nopeak[j] -1)/(eiz_nopeak[j] + 1))**2)*(eiz_peak[j]-eiz_nopeak[j])/(eiz_nopeak[j])
        sum_dF = sum_Li2[j] \
        *(1-((eiz_nopeak[j] -1)/(eiz_nopeak[j] + 1))**2)\
        /((eiz_nopeak[j] -1)/(eiz_nopeak[j] + 1))\
        *((eiz_peak[j]-eiz_nopeak[j])/(eiz_nopeak[j]))\
    
    pl.figure()
    pl.plot(n, sum_dF, color = 'r', label = '$\delta$F')
    pl.title(r'vdW Free Energy change as a function of n$^{th}$ Matsubara fequency')
    pl.xlabel(r'n')
    pl.ylabel(r'$\delta$$frac{F(D)}{S}$8$\pi$D$^{2}$/k$_{B}$T')
    
    sum_Li3[j] = 0.0
    sum_Li3_p[j] = 0.0
    for h in arange(101)+ 1:
        sum_Li3[j] += ((((eiz_nopeak[j] -1)/(eiz_nopeak[j] +1))**2)**h)/(h**3)
        sum_Li3_p[j] += ((((eiz_peak[j] -1)/(eiz_peak[j] +1))**2)**h)/(h**3)
    #sum_F +=   sum_Li3[j]
    sum_F[j] +=   sum_Li3[j]
    sum_F_p[j] += sum_Li3_p[j]
    #sum_F_p += sum_Li3_p[j]
    #diff_sum_F = (sum_F-sum_F_p)
    diff_sum_F[j] = (sum_F[j]-sum_F_p[j])
    pl.plot(n,diff_F, color = 'k', linestyle = '--', label = 'F$_{peak}$ - F$_{no peak}$')
    pl.legend()
    pp.savefig()
    pl.show()

print sum_dF
print sum_F
print sum_F_p
print diff_sum_F

dF = -sum_dF
#dF = -sum_Li2\
#*(1-((eiz_nopeak -1)/(eiz_nopeak + 1))**2)\
#/((eiz_nopeak -1)/(eiz_nopeak + 1))\
#*((eiz_peak-eiz_nopeak)/(eiz_nopeak))\

F_3 = -sum_Li3
F_3_p = -sum_Li3_p
diff_F = (-F_3+F_3_p)
divide = dF/diff_F 

## calc difference eps2 and eiz for with and without peak
#-----------------------------------------------------------
###diff_eps = y_peak - y_nopeak
###diff_eiz = eiz_peak - eiz_nopeak
###listofzeros = numpy.zeros(len(x_nopeak)) # plot line for y = 0
###
###contrast = (eiz_nopeak -1)/(eiz_nopeak + 1)
###contrast2 = ((eiz_nopeak -1)/(eiz_nopeak + 1))**2
###ratio_deiz = diff_eiz/eiz_nopeak
###
###divide_mult_con = contrast*(dF/diff_F) 
###divide_mult_del = ratio_deiz*(dF/diff_F) 
###diff_F_del = ratio_deiz*(-F_3+F_3_p)
###diff_F_del2 = ratio_deiz**2*(-F_3+F_3_p)
###diff_F_con = contrast*(-F_3+F_3_p)
###diff_F_con2 = contrast**2*(-F_3+F_3_p)
##### PLOTS
####-------------------------------------------------------------
###pl.figure() # Plot of eps2 for an initio (no peak) and synth (exciton peak added) 
###pl.plot(x_nopeak_eV,y_nopeak, color = 'b',label=r'ab initio eps2', linestyle='-')
####pl.plot(x_Y24204K, y_Y24204K, color = 'b',label=r'eps1, file Y24204K', linestyle='--')
###pl.plot(x_peak_eV, y_peak, color = 'g',label=r'eps2, file Y24204L', linestyle='-')
###pl.legend()
###pl.title(r'$\epsilon$"($\omega$)  Ab Initio and Synthisized')
###pl.xlabel(r'$\omega$')
###pl.ylabel(r'$\epsilon$"($\omega$)')
###pp.savefig()
###pl.show()
###
###pl.figure()
###pl.plot(x_Re_expt,y_Re_expt, color = 'g')
###pl.title('Real part of synthisized $\epsilon$($\omega$) vs $\omega$')
###pl.xlabel(r'$\omega$')
###pl.ylabel(r'Re$\epsilon$($\omega$)')
###pp.savefig()
###pl.show()
###
###pl.figure()
###pl.plot(x_nopeak, diff_eps, color= 'r', label=r'$\epsilon$"($\omega)_{peak}$ - $\epsilon$"($\omega)_{no peak}$')
###pl.plot(x_nopeak,listofzeros, color = 'k', label=r'$\delta$$\epsilon$"($\omega$) = 0')
###pl.title(r'Difference $\epsilon$"($\omega$) for Ab Initio (no peak) and Syntisized (peak)')
###pl.legend()
###pl.xlabel(r'$\omega$')
###pl.ylabel(r'$\delta$$\epsilon$"($\omega$)')
###pp.savefig()
###pl.show()
###
###pl.figure()
###pl.plot(n, eiz_peak, color = 'g', label = r'$\epsilon$(i$\zeta)_{peak}$')
###pl.plot(n, eiz_nopeak, color = 'b', label = r'$\epsilon$(i$\zeta)_{no peak}$')
###pl.legend()
###pl.title('$\epsilon$(i$\zeta$) vs $\zeta$')
###pl.xlabel('n')#(r'$\zeta_{n}$')
###pl.ylabel(r'$\epsilon$(i$\zeta$)')
###pp.savefig()
###pl.show()
###
###pl.figure()
###pl.plot(n, diff_eiz, color= 'r', label=r'$\epsilon$(i$\zeta)_{peak}$ - $\epsilon$($\zeta)_{no peak}$')
###pl.legend()
###pl.title('Difference $\epsilon$(i$\zeta$) vs $\zeta$')
###pl.xlabel('n')#(r'$\zeta$')
###pl.ylabel(r'$\delta$$\epsilon$(i$\zeta$)')
###pp.savefig()
###pl.show()
####
###pl.figure()
###pl.plot(n, ratio_deiz, color = 'm', label = r'$\delta$$\epsilon$(i$\zeta$)/$\epsilon$(i$\zeta$)$_{np}$')
###pl.plot(n, contrast, color = 'c', label = r'Contrast($\epsilon$(i$\zeta$)$_{np}$-1)/($\epsilon$(i$\zeta$)$_{np}$+1)')
###pl.legend()
###pl.title('difference ratio and Contrast for $\epsilon$(i$\zeta)_{no peak}$')
###pl.xlabel('n')#(r'$\zeta$')
###pp.savefig()
###pl.show()
###
###pl.figure()
###pl.plot(z,sum_Li2, color = 'y')
###pl.title(r'Dilog values vs $\zeta_{n}$')
###pl.xlabel(r'$\zeta_{n}$')
###pl.ylabel(r'Li$_{2}$')
###pp.savefig()
###pl.show()

#pl.figure()
#pl.plot(n,dF, color = 'r', label = '$\delta$F')
#pl.plot(n,diff_F, color = 'k', linestyle = '--', label = 'F$_{peak}$ - F$_{no peak}$')
####pl.plot(n,diff_F_del, color = 'b', linestyle = '--', label = 'delta ratio*(F$_{peak}$ - F$_{no peak}$)')
####pl.plot(n,diff_F_del2, color = 'g', linestyle = '--', label = 'delta ratio^2*(F$_{peak}$ - F$_{no peak}$)')
####pl.plot(n,diff_F_con, color = 'c', linestyle = '--', label = 'contrast*(F$_{peak}$ - F$_{no peak}$)')
####pl.plot(n,diff_F_con2, color = 'm', linestyle = '--', label = 'contrast2*(F$_{peak}$ - F$_{no peak}$)')
#pl.title(r'vdW Free Energy change as a function of n$^{th}$ Matsubara fequency')
#pl.xlabel(r'n')
#pl.ylabel(r'$\delta$$frac{F(D)}{S}$8$\pi$D$^{2}$/k$_{B}$T')
#pl.legend()
#pp.savefig()
#pl.show()
#
#pl.figure()
#pl.plot(n,F_3, color = 'k', label = '(F/S)$_{no peak}$')
#pl.plot(n,F_3_p, color = 'k', linestyle = '--', label = '(F/S)$_{peak}$')
#pl.title(r'vdW Free Energy as a function of n$^{th}$ Matsubara fequency')
#pl.xlabel(r'n')
#pl.ylabel(r'$frac{F(D)}{S}$8$\pi$D$^{2}$/k$_{B}$T')
#pl.legend()
#pp.savefig()
#pl.show()

###pl.figure()
###pl.plot(n,divide, color = 'k', label = 'A = $\delta$F/(F$_{peak}$ - F$_{no peak}$)')
###pl.plot(n,divide_mult_con, color = 'b', label = 'A * contrast')# \delta$F/(F$_{peak}$ - F$_{no peak}$)')
###pl.plot(n,divide_mult_del, color = 'r', label = 'A * delta ratio')#$\delta$F/(F$_{peak}$ - F$_{no peak}$)')
###pl.title(r'Ratio of $\delta$F and $\Delta$F as a function of n$^{th}$ Matsubara fequency')
###pl.xlabel(r'n')
###pl.legend()
###pp.savefig()
###pl.show()

pp.close()
pl.close()

