#!/usr/bin/python
import matplotlib               
import numpy                    
from pylab import *
from matplotlib import pyplot as pl

a = arange(0,10)
c = numpy.empty(len(a))

for b in range(len(a)):
    if b == 0:
        c = a[b]+20
    else:
        c = a[b]+1
    print c

