#!/usr/bin/python
import matplotlib               
import numpy                    
from pylab import *
from matplotlib import pyplot as pl
from matplotlib import axis as ax
from matplotlib.ticker import MultipleLocator#, FormatStrFormatter

x_WYC_asio2, y_WYC_asio2 = numpy.loadtxt('a-sio2-eps2.txt', unpack=True, usecols = [0,1])

x_Y24204K, y_Y24204K = numpy.loadtxt('Y24204K.txt', unpack=True, usecols = [0,1])
x_Y24204L, y_Y24204L = numpy.loadtxt('Y24204L.txt', unpack=True, usecols = [0,1])
x_Y24204S, y_Y24204S = numpy.loadtxt('Y24204S.txt', unpack=True, usecols = [0,1])

#minorLocator = MultipleLocator(5)

pl.figure(1)
pl.plot(x_WYC_asio2,y_WYC_asio2, color = 'k',label=r'ab initio eps2', linestyle='-')
pl.plot(x_Y24204K, y_Y24204K, color = 'b',label=r'eps1, file Y24204K', linestyle='--')
pl.plot(x_Y24204L, y_Y24204L, color = 'r',label=r'eps2, file Y24204L', linestyle='-')
pl.legend()
pl.title(r'eps- Ab Initio and Syntisized')
pl.xlabel(r'eV')
pl.ylabel(r'eps')
#ax.get_minor_ticks(10)
pl.show(1)

pl.figure(2)
pl.plot(x_Y24204S, y_Y24204S, color = 'g',label='fSum Rule, file Y24204S', linestyle='-')
pl.legend()
pl.title('fSum Rule for Experimental Data')
#lyplot.xlabel(r'eV')
#lyplot.ylabel(r'$/epsilon(/omega)$')
pl.show(2)

