from numpy import *
from numpy import linalg as la
import matplotlib.pyplot as pl
import scipy.integrate as grt
import sys
from matplotlib.backends.backend_pdf import PdfPages
pp = PdfPages('130701_Hopkins_eiz.pdf')
#from newsavetxt import *

eda,yda = loadtxt('Dan_a_sio2.dat', unpack=True, usecols=[0,1])
edqz,ydqz = loadtxt('Dan_q_sio2_z.dat', unpack=True, usecols=[0,1])
edqx,ydqx = loadtxt('Dan_q_sio2_x.dat', unpack=True, usecols=[0,1])

ewq,ywq,ywqx,ywqy,ywqz = loadtxt('wyc_c_input.dat', unpack=True, usecols=[0,1,2,3,4])
ewa,ywa,ywax,yway,ywaz = loadtxt('wyc_a_input.dat', unpack=True, usecols=[0,1,2,3,4])

eex,yex = loadtxt('wyc_input_no_exciton.dat', unpack=True, usecols=[0,1])
w,e = loadtxt('Dan_a_sio2.dat', unpack=True, usecols=[0,1])
wex,eex = loadtxt('wyc_input_no_exciton.dat', unpack=True, usecols=[0,1])

zs = arange(0,100)
waiyimqs = [ywq,ywqx,ywqy,ywqz]
waiyimas = [ywa,ywax,yway,ywaz]

def k(energy,eps2,ham):
	return (energy*eps2)/(energy**2 + ham**2)

def eo(energy,eps2):
	return eps2/energy

def ein(energy,eps2):
	return energy*eps2

def eiz(low,inf,ham):
	return 1. + low/ (1. + ham**2 * low/inf)

#colors = ['k','#2E9AFE','#04B404','r','g','c','m','y']
markers = ['x','s','^','d']
labwaiyimqs = ['ywq','ywqx','ywqy','ywqz']
labwaiyimas = ['ywa','ywax','yway','ywaz']

for a,waiyimq in enumerate(waiyimqs): 
	#for j,z in enumerate(zs):
	labels= labwaiyimqs[a]
	kqs = [k(ewq,waiyimq,z) for z in zs]
	#kqzs = [k(ewqs,waiyimq,zs) for ewqs in ewq]
		#kqs = k(ewq,waiyimq,z) 
		#kqs = k(ewq,waiyimq,zs) 
		#Kq = 1. + (2./pi) * grt.simps(kqs,ewq)
	for i,integrand in enumerate(kqs):
		Kq = 1. + (2./pi) * grt.simps(kqs,ewq)
#	for i,integrand in enumerate(kqs):
#		Kzq = 1. + (2./pi) * grt.simps(kqs,zs)
#		##KK1 = sum(K1)
#
#		pl.figure(3)
#		pl.plot(kqs,Kzq)
	pl.figure(1)
	pl.plot(0.412*zs,Kq,linestyle ='-', linewidth=1,color ='c', marker=markers[a], markersize=2,markevery=20, label =labels)
	eqo = eo(ewq,waiyimq)
	Eqo = (2./pi)*grt.simps(eqo,ewq)
	eqin = ein(ewq,waiyimq)
	Eqin = (2./pi)*grt.simps(eqin,ewq)
	#eqiz = [eiz(Eqo,Eqin,z) for z in zs] 
	eqiz = eiz(Eqo,Eqin,zs)
	pl.plot(0.412*zs,eqiz, linestyle = ':',linewidth=1, color = 'c', marker = markers[a],markersize=4,markevery=10,)
#import sys; sys.exit()
	pl.figure(2)
	pl.plot(0.412*zs,100*abs(eqiz-Kq)/Kq, color ='c',marker =markers[a],markersize=4,markevery=10,linestyle ='-',label=labels)
for b,waiyima in enumerate(waiyimas): 
	labels= labwaiyimas[b]
	kas = [k(ewa,waiyima,z) for z in zs]
	for j,integrand in enumerate(kas):
		Ka = 1. + (2./pi) * grt.simps(kas,ewa)
		#KK1 = sum(K1)
	pl.figure(1)
	pl.plot(0.412*zs,Ka, linestyle = '-', color = 'g',marker =markers[b],markersize=4,markevery=10, label =labels)
	eao = eo(ewa,waiyima)
	Eao = (2./pi)*grt.simps(eao,ewa)
	eain = ein(ewa,waiyima)
	Eain = (2./pi)*grt.simps(eain,ewa)
	eaiz = eiz(Eao,Eain,zs) 
	pl.plot(0.412*zs,eaiz, linestyle = ':', color = 'g',marker =markers[b],markersize=4,markevery=10)
	pl.figure(2)
	pl.plot(0.412*zs,100*abs(eaiz-Ka)/Ka, color = 'g',marker =markers[b],markersize=4,markevery=10, linestyle = '-', label = labels)

pl.figure(1)
kda = [k(eda,yda,z) for z in zs]
kdqx = [k(edqx,ydqx,z) for z in zs]
kdqz = [k(edqz,ydqz,z) for z in zs]

Kda = 1. + (2./pi) * grt.simps(kda,eda)
Kdqx = 1. + (2./pi) * grt.simps(kdqx,edqx)
Kdqz = 1. + (2./pi) * grt.simps(kdqz,edqz)

pl.plot(0.412*zs,Kda, linestyle = '-', color = 'b', label = 'kk dan amor')
pl.plot(0.412*zs,Kdqx, linestyle = '-', color = 'r', label = 'kk dan q x')
#pl.plot(0.412*zs,Kdqz, linestyle = '-', color = 'k', label = 'kk dan q z')
#import sys
#sys.exit()

edao = eo(eda,yda)
Edao = (2./pi)*grt.simps(edao,eda)

edqxo = eo(edqx,ydqx)
Edqxo = (2./pi)*grt.simps(edqxo,edqx)

edqzo = eo(edqz,ydqz)
Edqzo = (2./pi)*grt.simps(edqzo,edqz)

edain = ein(eda,yda)
Edain = (2./pi)*grt.simps(edain,eda)

edqxin = ein(edqx,ydqx)
Edqxin = (2./pi)*grt.simps(edqxin,edqx)

edqzin = ein(edqz,ydqz)
Edqzin = (2./pi)*grt.simps(edqzin,edqz)

edaiz = eiz(Edao,Edain,zs) 
edqxiz = eiz(Edqxo,Edqxin,zs) 
edqziz = eiz(Edqzo,Edqzin,zs) 

pl.plot(0.412*zs,edaiz, color = 'b',  linestyle = ':')
pl.plot(0.412*zs,edqxiz, color = 'r',  linestyle = ':')
#pl.plot(0.412*zs,edqziz, color = 'k',  linestyle = ':')

pl.figure(2)
pl.plot(0.412*zs,100*abs(edaiz-Kda)/Kda, color = 'b',  linestyle = '-', label = 'dan amor')
pl.plot(0.412*zs,100*abs(edqxiz-Kdqx)/Kdqx, color = 'r',  linestyle = '-', label = 'dan q x')
#pl.plot(0.412*zs,100*abs(edqziz-Kdqz)/Kdqz, color = 'k',  linestyle = '-', label = 'dan q z')

####kex = [(wex*eex)/(wex**2 + z**2) for z in zs]
#####K = 1. + (2./pi) * grt.simps(k,w)
####Kex = zeros(len(zs))
####for i,integrandex in enumerate(kex):
####	Kex[i] = 1. + (2./pi) * grt.simps(integrandex,wex)
####KKex = sum(Kex)
####
####eo = e/w
####Eo = (2./pi)*grt.simps(eo,w)
####print eo
####print 'Eo = %.3f' % (Eo)
####
####ein = e*w
####Ein = (2./pi)*grt.simps(ein,w)
####print ein
####print 'Ein = %.3f' % (Ein)
####
####eoex = eex/wex
####Eoex = (2./pi)*grt.simps(eoex,wex)
#####print eo
#####print 'Eo = %.3f' % (Eo)
####
####einex = eex*wex
####Einex = (2./pi)*grt.simps(einex,wex)
#####print ein
#####print 'Ein = %.3f' % (Ein)
####
####eiz = [1. + Eo/ (1. + z**2 * Eo/Ein) for z in zs] 
####eizex = [1. + Eoex/ (1. + z**2 * Eoex/Einex) for z in zs] 
####seiz = sum(eiz)
####print 'sum = %.3f' % (seiz) 

#dif1 = (KK1 - seiz)/KK1
#dif2 = (KK2 - seiz)/KK2
#print 'diff = %.3f' %(dif1)

#neiz = la.norm(eiz)
#nK = la.norm(K)

#eizdotK = [dot(eizs,Ks)/(neiz*nK) for eizs,Ks in zip(eiz,K)]
##neizdotK = grt.simps(eizdotK)
#pl.figure()
#pl.plot(0.412*zs, eizdotK)
#pl.title('Transforms overlap, normed dot product of Approx,K-K transforms')

#pl.plot(e,z)
pl.figure(1)
pl.title(r'$\epsilon$(i$\xi$) Approx and K-K transforms for a-SiO2 data from WYC')
pl.xlabel(r'eV',size = 'x-large')#'$\omega$', size =5 'x-large')
pl.ylabel(r'$\epsilon$(i$\xi$)', size = 'x-large')#^{i,o}$,$\Phi_{m}^{o}$,$\Phi_{b}^{o}$,$\Delta f$)', size = 'x-large')
#pl.title(r'$\epsilon$"($\omega$) vs $\omega$ for a-SiO2 data from WYC')# Fig.1$P_{s}$ for varied $\Delta f$, fixed $\Phi_{s}^{o}$, $\Phi_{m}^{o\ only}$, $\Phi_{b}^{o\ only}$')
#pl.plot(w,e) #marker=markerss[h],color = colors[k],linestyle = lts[i],linewidth= 0.7,markersize=4,markevery=7)
#pl.title(r'$\epsilon$"($\omega$) vs $\omega$ for a-SiO2 data from WYC')# Fig.1$P_{s}$ for varied $\Delta f$, fixed $\Phi_{s}^{o}$, $\Phi_{m}^{o\ only}$, $\Phi_{b}^{o\ only}$')
#pl.xlabel(r'$\omega$', size = 'x-large')
#pl.ylabel(r'$\epsilon$"($\omega$)', size = 'x-large')#^{i,o}$,$\Phi_{m}^{o}$,$\Phi_{b}^{o}$,$\Delta f$)', size = 'x-large')
pl.axis([0.0,42, 1.0, 6.1])
pl.legend(loc='upper right')
pl.show()
pp.savefig(1)

pl.figure(2)
####pl.plot(0.412*zs,100*abs(eiz-Kda)/Kda, color = 'c',  linestyle = ':', label = 'Dan aSiO2 vals')
####pl.plot(0.412*zs,100*abs(eiz-Kdqz)/Kdqz, color = 'c',  linestyle = '-.', label = 'Dan aSiO2 vals')
####pl.plot(0.412*zs,100*abs(eiz-Kdqx)/Kdqx, color = 'c',  linestyle = '--', label = 'Dan aSiO2 vals')
####pl.plot(0.412*zs,100*abs(eizex-Kex)/Kex, color = 'g', linestyle = '-', label = 'WYC aSiO2 - peak1')
pl.title('Percent Difference between Approx and K-K')
#pl.plot(6.24e18*6.0e-21*zs,abs(eiz-K)/K)
pl.xlabel(r'eV',size = 'x-large')#'$\omega$', size = 'x-large')
pl.ylabel(r'Percent', size = 'x-large')#^{i,o}$,$\Phi_{m}^{o}$,$\Phi_{b}^{o}$,$\Delta f$)', size = 'x-large')
pl.legend(loc='upper right')
pp.savefig(2)
pl.show()
pp.close()
#DataOut = column_stack((e,eps))
#savetxt('wyc_output.dat',DataOut)#,fmt=('%10.7f','%10.7f'))

##savetxthd('output.dat',DataOut,fmt=('%10.7f','%10.7f'),header='#energy and epsilon sq\n')



